#!/bin/bash
if [ "$(whoami)" != "root" ] ; then
        echo "Please run as root"
        echo "Quitting ..."
        exit 1
fi

# Replace base DTB files
mv tegra234-p3701-0000-p3737-0000.dtb Linux_for_Tegra/kernel/dtb/
mv tegra234-p3701-0004-p3737-0000.dtb Linux_for_Tegra/kernel/dtb/

# Replace kernel Image & nvgpu.ko
mv Image Linux_for_Tegra/kernel/
sudo mv nvgpu.ko Linux_for_Tegra/rootfs/usr/lib/modules/5.10.104-tegra/kernel/drivers/gpu/nvgpu/
sudo rm Linux_for_Tegra/rootfs/lib/modules/5.10.104-tegra/kernel/drivers/net/ethernet/microchip/lan743x.ko
sudo rm Linux_for_Tegra/rootfs/lib/modules/5.10.104-tegra/kernel/drivers/net/usb/cdc_mbim.ko
sudo rm Linux_for_Tegra/rootfs/lib/modules/5.10.104-tegra/kernel/drivers/usb/class/cdc-wdm.ko

# Replace pinmux files
mv tegra234-mb1-bct-pinmux-p3701-0000.dtsi Linux_for_Tegra/bootloader/t186ref/BCT/
mv tegra234-mb1-bct-pinmux-p3701-0000-a04.dtsi Linux_for_Tegra/bootloader/t186ref/BCT/
mv tegra234-mb1-bct-gpio-p3701-0000.dtsi Linux_for_Tegra/bootloader/

# Apply the system config
sudo -u $SUDO_USER tar -xjf t234-dram-package-35.2.1_2025-12-03.tbz2
sudo -u $SUDO_USER tar -xjf t234-pcn210100-pcn211461-emmc-35.2.1.tbz2
sed -i "s/cvb_eeprom_read_size = <0x100>;/cvb_eeprom_read_size = <0x0>;/g" Linux_for_Tegra/bootloader/tegra234-mb2-bct-common.dtsi
sed -i "s/ODMDATA=\"gbe-uphy-config-22,hsstp-lane-map-3,nvhs-uphy-config-0,hsio-uphy-config-0,gbe0-enable-10g\";/ODMDATA=\"gbe-uphy-config-0,hsstp-lane-map-3,hsio-uphy-config-16,nvhs-uphy-config-0\";/g" Linux_for_Tegra/p3701.conf.common

# cat Linux_for_Tegra/bootloader/tegra234-mb2-bct-common.dtsi | grep eeprom
# cat Linux_for_Tegra/p3701.conf.common | grep ODMDATA

echo "Done."

